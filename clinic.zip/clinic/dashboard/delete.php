<?php
if(isset($_GET['id']))
{
	
	$servername = "localhost";
	$database = "clinic_admin_users";
	$username = "root";
	$password = "";
	// Create connection
	$conn = new mysqli($servername, $username, $password,$database);
	// Check connection
	if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
	}
	$userId = $_GET['id'];
	// write sql query for inserting data into patient table.	
	$sql = "delete from patient where id = '$userId'";

	if ($conn->query($sql) === TRUE) {
	header("Location:user_list.php?q=deleted");
	} else {
	echo "Error: " . $sql . "<br>" . $conn->error;
	}
	$conn->close();

} 
?>