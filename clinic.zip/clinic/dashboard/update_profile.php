<?php

// file name update_profile.php
if(isset($_GET['id']) && $_GET['id'] > 0)
{ 
// database connection, to get user data along with images
	$servername = "localhost";
	$database = "clinic_admin_users";
	$username = "root";
	$password = "";

	// Create connection
	$conn = new mysqli($servername, $username, $password,$database);

	// Check connection
	if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
	}
	
	$userId = $_GET['id'];
	// write sql query for inserting data into cases table.	
	$sql = "SELECT * FROM patient where id = '$userId'";
	$exe_query = $conn->query($sql);
	$result = $exe_query->fetch_assoc()
	
?>
<!DOCTYPE html>
<html>
<head><title>Update patient</title>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> 

            <style>  
         body  
         {  
         margin:0;  
         padding:0;  
         background-color:#f1f1f1;  
         }  
         .box  
         {  
         width:750px;  
         padding:20px;  
         background-color:#fff;  
         border:1px solid #ccc;  
         border-radius:5px;  
         margin-top:10px;  
         }

      </style>

</head>
<body>

	      <div class="container box">
         <h3 align="center">Update Appointment</h3>
         <br /><br />  
         <br /><br /> 

<form action="update.php" method="post" enctype="multipart/form-data">

                     <label>Patient Name :</label>
                     <input value="<?php echo $result['name'];?>" type="text" name="name" id="name" class="form-control" required="required" ><br/>

                     <label>Patient Surname :</label> 
                     <input value="<?php echo $result['surname'];?>" type="text" name="surname" id="surname" class="form-control" required="required"><br/>

                     <label for="birthday">Date of Birth:</label>
                     <input value="<?php echo $result['birthday'];?>" type="date" id="birthday" name="birthday" required="required"><br/><br/>

                     <label>Email address :</label>
                     <input value="<?php echo $result['email'];?>" type="text" name="email" id="email" class="form-control" ><br/> 

                     <label>Phone number :</label>   
                     <input value="<?php echo $result['phone'];?>" type="number" name="phone" id="phone" class="form-control" required="required"><br/>  

                     <label for="gender">Choose Gender:</label>
                     <select value="<?php echo $result['gender'];?>" name="gender" id="gender">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                     </select>
                     <br><br>

                     <label for="timeSlot">Time of the Day:</label>
                     <input value="<?php echo $result['timeSlot'];?>" type="time" id="timeSlot" name="timeSlot" required="required"><br/><br/>

  
  Picture:  <input  type="file" name="img" id="img"> <br/>
	<img style="height: 100px;width: 80px;"  height="50" src="<?php echo $result['img'];?>">
	<input type="hidden"  id="img" name="img" value="<?php echo $result['img'];?>">

	<input type="hidden" name="id" value="<?php echo $result['id'];?>">	
  <br/>
  <br>
	
  <input type="submit" value="Update" name="submit">
</form>

</div>

</body>
</html>

<?php }?>