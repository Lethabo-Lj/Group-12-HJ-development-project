<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Appointments</title>

    <link rel="stylesheet" href="style.css">

</head>
<body>
   
    <div class="wrapper">
        <div class="section">
         
                <div class="hamburger">
                    <a href="#">
                        <i class="fas fa-bars"></i>
                    </a>
                </div>

        </div>

        <div class="main">

        <div class="sideLeft">
        <div class="sidebar">
            <div class="profile">
  
                <h3>Welcome</h3>
                
            </div>
               <ul>
                  <li>
                     <a href="index.php" >
                     <span class="icon"><i class="fas fa-home"></i></span>
                     <span class="item">Book Patient</span>
                     </a>
                     <div class="MainContainer">
                  </li>
                  <li>
                  <a href="admin.php">
                  <span class="icon"><i class="fas fa-user-friends"></i></span>
                  <span class="item">Admin</span>
                  </a>
                  </li>
                  <li>
                  <a href="user_list.php" class="active">
                  <span class="icon"><i class="fas fa-database"></i></span>
                  <span class="item">Appointments</span>
                  </a>
                  </li>
                  <li>
                  <a href="../login.php">
                  <span class="icon"><i class="fas fa-cog"></i></span>
                  <span class="item">LogOut</span>
                  </a>
                  </li>
               </ul>        </div>
        </div>
        <div class="sideRight">

<?php
// flag to print action message
if(isset($_GET['q']) && $_GET['q']=='save')
{
 echo "Successfully Saved.";
}
if(isset($_GET['q']) && $_GET['q']=='deleted')
{
 echo "Successfully Deleted";
}	

if(isset($_GET['q']) && $_GET['q']=='update')
{
 echo "Successfully Updated";
}	
// flag to print action message end

	// database connection, to get user data along with images
	$servername = "localhost";
	$database = "clinic_admin_users";
	$username = "root";
	$password = "";

	// Create connection
	$conn = new mysqli($servername, $username, $password,$database);

	// Check connection
	if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
	}

	// write sql query for inserting data into patient table.	
	$sql = "SELECT * FROM patient";
	$result = $conn->query($sql);
	
	if ($result->num_rows > 0) {?>

	<table border="1" width="80%">
		<tr>
		 <td>Patient No.</td>
		 <td>Patient Name</td>
		 <td>Patient Surname</td>
		 <td>Patient Date of Birth</td>
		 <td>Patient Email</td>
		 <td>Patient Phone number</td>
		 <td>Patient Gender</td>
         <td>Patient timeSlot</td>
		 <td>Patient Picture</td>
		 <td>Action</td>
		 </tr>
	<?php $k = 1;
	while($row = $result->fetch_assoc()) { ?>
	    			
		<tr>
		 <td><?php echo $k++;?></td>
		 <td><?php echo $row['name'];?></td>
		 <td><?php echo $row['surname'];?></td>
		 <td><?php echo $row['birthday'];?></td>
		 <td><?php echo $row['email'];?></td>
		 <td><?php echo $row['phone'];?></td>
         <td><?php echo $row['gender'];?></td>
         <td><?php echo $row['timeSlot'];?></td>

		 <td><img height="100" src="<?php echo $row['img'];?>"  ></td>
		 
		 <td><a href="delete.php?id=<?php echo $row['id'];?>"> Delete </a> | <a href="update_profile.php?id=<?php echo $row['id'];?>"> Edit </a></td>
		 
		 </tr>
		 
	<?php }
	
	echo "<table/>";
	
	}
?>
<br/>
<a href="index.php"> Add Patient</a>

       </div>
        </div>
        
    </div>
  <script>
       var hamburger = document.querySelector(".hamburger");
	hamburger.addEventListener("click", function(){
		document.querySelector("body").classList.toggle("active");
	})

  </script>
</body>
</html>