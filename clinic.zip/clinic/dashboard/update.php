<?php
if(isset($_POST))
{
	$name = $_POST['name'];
	$surname = $_POST['surname'];
	$birthday = $_POST['birthday'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$gender = $_POST['gender'];
	$timeSlot = $_POST['timeSlot'];
	$img = $_POST['img'];

	$id =    $_POST['id'];
	$to_upload_path = "";
	
	if(isset($_FILES) && !empty($_FILES))
	{
		$filename = $_FILES["img"]["name"];
		$to_upload_path = "uploads/".$filename;
		if(move_uploaded_file($_FILES["img"]["tmp_name"], $to_upload_path))
		{
			
		}else{
		$to_upload_path = $_POST['img'];
		}		
	}
	
	$servername = "localhost";
	$database = "clinic_admin_users";
	$username = "root";
	$password = "";

	// Create connection
	$conn = new mysqli($servername, $username, $password,$database);

	// Check connection
	if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
	}
	
	// write sql query for inserting data into patient table.	
	$sql = "update patient set  name = '$name', surname = '$surname', birthday = '$birthday', email = '$email', phone = '$phone', gender = '$gender', timeSlot = '$timeSlot' , img ='$to_upload_path' where id = '$id'";

	if ($conn->query($sql) === TRUE) {
	header("Location:user_list.php?q=update");
	} else {
	echo "Error: " . $sql . "<br>" . $conn->error;
	}
	$conn->close();

} 
?>