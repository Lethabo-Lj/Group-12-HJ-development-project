<!DOCTYPE html>
<html>
   <head>
      <title></title>
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> 
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="style-3.css">

   </head>
   <body>
      <div class="wrapper">
      <div class="section">
         <div class="top_navbar">
         <div class="hamburger">
            <a href="#">
            <i class="fas fa-bars"></i>
            </a>
         </div>
      </div>
   </div>
      <div class="main">
         <div class="sideLeft">
            <div class="sidebar">
               <div class="profile">
                  <h3>Welcome</h3>
               </div>
               <ul>
                  <li>
                     <a href="index.php" class="active">
                     <span class="icon"><i class="fas fa-home"></i></span>
                     <span class="item">Book Patient</span>
                     </a>
                     <div class="MainContainer">
                  </li>
                  <li>
                  <a href="admin.php">
                  <span class="icon"><i class="fas fa-user-friends"></i></span>
                  <span class="item">Admin</span>
                  </a>
                  </li>
                  <li>
                  <a href="user_list.php">
                  <span class="icon"><i class="fas fa-database"></i></span>
                  <span class="item">Appointments</span>
                  </a>
                  </li>
                  <li>
                  <a href="../login.php">
                  <span class="icon"><i class="fas fa-cog"></i></span>
                  <span class="item">LogOut</span>
                  </a>
                  </li>
               </ul>
               </div>
            </div>
            <div class="sideRight">
               <div class="container box">
                  <h3 align="center">Book Appointment For Patient</h3>
                  <br /><br />  
                  <br /><br />  
                  <form action="upload.php" method="post" enctype="multipart/form-data">
                     <label>Patient Name :</label>    <input type="text" name="name" id="name" class="form-control" required="required"><br/>
                     <label>Patient Surname :</label>    <input type="text" name="surname" id="surname" class="form-control" required="required"><br/>
                     <label for="birthday">Date of Birth:</label>
                     <input type="date" id="birthday" name="birthday" required="required"><br/><br/>
                     <label>Email address :</label>   <input type="text" name="email" id="email" class="form-control" ><br/>  
                     <label>Phone number :</label>   <input type="number" name="phone" id="phone" class="form-control" required="required"><br/>  
                     <label for="gender">Choose Gender:</label>
                     <select name="gender" id="gender">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                     </select>
                     <br><br>
                     <label for="timeSlot">Time of the Day:</label>
                     <input type="time" id="timeSlot" name="timeSlot" required="required"><br/><br/>
                     <label>Picture</label>  <input type="file" name="img" id="img"><br/>
                     <button type="submit" value="Submit" name="submit" class="button button2">Book</button>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>