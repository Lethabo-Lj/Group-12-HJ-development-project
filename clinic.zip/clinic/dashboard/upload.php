<?php
if(isset($_POST))
{
	$name = $_POST['name'];
	$surname = $_POST['surname'];
	$birthday = $_POST['birthday'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$gender = $_POST['gender'];
	$timeSlot = $_POST['timeSlot'];
	$img = $_POST['img'];

	$to_upload_path = "";
	
	if(isset($_FILES) && !empty($_FILES))
	{
		$filename = $_FILES["img"]["name"];

		$to_upload_path = "uploads/".$filename; 
               // uploads folder must be inside your project root directory
		move_uploaded_file($_FILES["img"]["tmp_name"], $to_upload_path);		
	}
	
	$servername = "localhost";
	$database = "clinic_admin_users";
	$username = "root";
	$password = "";

	// Create connection
	$conn = new mysqli($servername, $username, $password,$database);

	// Check connection
	if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
	}

	// write sql query for inserting data into patient table.	
	$sql = "INSERT INTO patient (name, surname,birthday,email, phone, gender, timeSlot, img)
	VALUES ('$name','$surname','$birthday' ,'$email','$phone', '$gender','$timeSlot', '$to_upload_path')";

	if ($conn->query($sql) === TRUE) {
	header("Location:user_list.php?q=save");
	} else {
	echo "Error: " . $sql . "<br>" . $conn->error;
	}
	$conn->close();

} 
?>