<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "clinic_admin_users";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";
"<br>";
$Email = $_POST['Email'];
$Password = $_POST['Password'];


$sql="select * from admin_Users where (Email='$Email' and Password='$Password');";

      $res=mysqli_query($conn,$sql);

      if (mysqli_num_rows($res) > 0) {
        
        $row = mysqli_fetch_assoc($res);
        if($Email==isset($row['Email']) and $Password==isset($row['Password']))
        {
            	echo "You have successfully login";
            	header("Location: dashboard/index.php");
				"<br>";
        }
	}
else{
	"<br>";
	echo "Email or Username is incorrect";
}

?>


<!DOCTYPE html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Transparent Login Form HTML CSS</title>
	<link href="style-2.css" rel="stylesheet">
    </head>
<body>
	<div class="form-box">
<div class="header-text"><a style="color: white;text-decoration: none;" href="signup.php">Signup</a> <a style="color: white;" href="login.php"> / Login </a></div>
	
	<form method="POST" class="register-form" id="register-form" action="verify.php">
		<input required="required" name="Email" id="Email" placeholder="Your Email Address" type="text"> 
		<input required="required" name="Password" id="Password" placeholder="Your Password" type="password"> 
	
		<button>login</button>
		
		</form>
	</div>
</body>
</html>
