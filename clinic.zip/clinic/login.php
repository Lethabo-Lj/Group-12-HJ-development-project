<!DOCTYPE html>
<!--www.codingflicks.com--> 
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Clinic application</title>
	<link href="style-2.css" rel="stylesheet">
	
</head>
<body>
	<div class="form-box">
<div class="header-text"><a style="color: white;text-decoration: none;" href="signup.php">Signup</a> <a style="color: white;" href="login.php"> / Login </a></div>
	
	<form method="POST" class="register-form" id="register-form" action="verify.php">
		<input required="required" name="Email" id="Email" placeholder="Your Email Address" type="text"> 
		<input required="required" name="Password" id="Password" placeholder="Your Password" type="password"> 
	
		<button>login</button>
		
		</form>
	</div>
</body>
</html>
