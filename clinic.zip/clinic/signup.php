<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "clinic_admin_users";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";
if(isset($_POST['signup']))
{
$Name = $_POST['Name'];
$Email = $_POST['Email'];
$Password = $_POST['Password'];


// database insert SQL code
$sql = "INSERT INTO admin_Users (Name, Email, Password) 
        VALUES ('$Name', '$Email', '$Password')";

        


//$rs = mysqli_query($conn, $sql);

if(mysqli_query($conn, $sql))
{
	echo "You are successfully registered, please login";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}
?>



<!DOCTYPE html>
<!--www.codingflicks.com--> 
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Clinic application</title>
	<link href="style-2.css" rel="stylesheet">
	
</head>
<body>
	<div class="form-box">
		<div class="header-text"><a style="color: white;" href="login.php">Signup</a> <a style="color: white;text-decoration: none;" href="login.php"> / Login </a></div>
		
		<form method="POST" class="register-form" id="register-form" action="signup.php">
		<input required="required" name="Name" id="Name" placeholder="Your Name" type="text"> 
		<input required="required" name="Email" id="Email" placeholder="Your Email Address" type="text"> 
		<input required="required" name="Password" id="Password" placeholder="Your Password" type="password">
		
		<button type="submit" name="signup" id="signup" class="form-submit" value="Register">Signup</button>

		<a href="camera.html" style="color: white"> Click here to uplod image(testing) </a>

		</form>
	</div>
</body>
</html>